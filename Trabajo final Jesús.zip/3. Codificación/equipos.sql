INSERT INTO `equipos` (`Nombre`, `Ciudad`, `País`) VALUES
('Instituto Raimon', 'Ciudad Inazuma', 'Japón'),
('Royal Academy', 'Ciudad Inazuma', 'Japón'),
('Academia Alius', 'Tokio', 'Japón'),
('Raimon GO', 'Ciudad Inazuma', 'Japón');
