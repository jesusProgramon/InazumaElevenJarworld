BIENVENIDO AL MUNDO DE INAZUMA ELEVEN!

Para poder jugar, necesitas seguir los siguientes pasos:

1. Instalar XAMPP: https://www.apachefriends.org/download.html
2. Inicializar servidores Apache Web Server y MySQL Database en XAMPP
3. Abrir tu navegador de confianza y poner en la barra de direcciones "localhost" sin comillas
4. Entrar en phpMyAdmin
5. Crear una nueva base de datos (botón new a la izquierda) y llamarla inazuma_db
6. Click en la nueva base de datos, click en "Import", e importar "inazuma_db.sql"
7. Abrir una terminal donde tengas el .jar y ejecutar:
 - Windows: java -cp "bin;lib/*" inazuma.Programa
 - Linux y Mac: java -cp "bin:lib/*" inazuma.Programa

LISTO! JUGUEMOS AL FÚTBOL!
